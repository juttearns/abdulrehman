import { useState } from 'react'
import Reveal from './Reveal.jsx'

function ProjectCard({ project, featured }) {
  const [open, setOpen] = useState(false)
  return (
    <article className={`glass project-card${featured ? ' featured' : ''}`}>
      <div className="project-head">
        <div>
          <h3>{project.name}</h3>
          <p className="project-tagline">{project.tagline}</p>
        </div>
        {project.link ? (
          <a href={project.link} target="_blank" rel="noreferrer" className="project-link" aria-label={`Open ${project.name}`}>
            ↗
          </a>
        ) : null}
      </div>
      <p className="project-desc">{project.description}</p>
      <div className="tag-row">
        {(project.tags || []).map((t) => <span key={t} className="tag">{t}</span>)}
      </div>
      {project.blog ? (
        <div className="project-blog">
          <button className="link-btn" onClick={() => setOpen((v) => !v)}>
            {open ? 'Hide notes' : 'Read the notes'}
          </button>
          {open && <p className="project-blog-text">{project.blog}</p>}
        </div>
      ) : null}
    </article>
  )
}

export default function Projects({ projects }) {
  return (
    <section id="work" className="section">
      <div className="container">
        <Reveal>
          <p className="eyebrow">Work</p>
          <h2 className="section-title">Shipped, not just prototyped.</h2>
        </Reveal>
        <div className="project-grid">
          {projects.map((p, i) => (
            <Reveal key={p.id} as="div" className={`project-grid-item${i === 0 ? ' featured-item' : ''}`}>
              <ProjectCard project={p} featured={i === 0} />
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  )
}
