import Reveal from './Reveal.jsx'

export default function About({ profile }) {
  return (
    <section id="about" className="section">
      <div className="container">
        <Reveal>
          <p className="eyebrow">About</p>
          <h2 className="section-title">No office. No team. No excuses.</h2>
        </Reveal>
        <Reveal className="about-grid">
          <div>
            <p className="about-bio">{profile.bio}</p>
            <p className="about-skills-label">Works with</p>
            <div className="skill-list">
              {(profile.skills || []).map((s) => (
                <span key={s} className="tag">{s}</span>
              ))}
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  )
}
