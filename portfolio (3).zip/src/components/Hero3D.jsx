import { Suspense, useMemo, useRef, useState } from 'react'
import { Canvas, useFrame } from '@react-three/fiber'
import { Environment, Lightformer, RoundedBox, Float } from '@react-three/drei'
import { EffectComposer, Bloom } from '@react-three/postprocessing'
import * as THREE from 'three'

// A loose helix of floating panels: each one stands in for a shipped
// product. Motivated choice over an abstract shape, since this is a
// portfolio and the piece should read as "many things built."
const PANEL_COUNT_FULL = 7
const PANEL_COUNT_LITE = 4

function Panel({ index, total, radius, quality, lead }) {
  const ref = useRef()
  const phase = useMemo(() => (index / total) * Math.PI * 2, [index, total])
  const yBase = useMemo(() => (index / (total - 1) - 0.5) * 3.4, [index, total])
  const w = lead ? 1.5 : 1.05 + (index % 3) * 0.08
  const h = lead ? 1.0 : 0.68 + (index % 2) * 0.06

  useFrame((state) => {
    if (!ref.current) return
    const t = state.clock.getElapsedTime()
    const drift = quality.reduceMotion ? 0 : t * 0.09
    const a = phase + drift
    const px = state.pointer.x
    const py = state.pointer.y
    ref.current.position.x = Math.cos(a) * radius
    ref.current.position.z = Math.sin(a) * radius * 0.55
    ref.current.position.y = yBase + (quality.reduceMotion ? 0 : Math.sin(t * 0.35 + phase) * 0.18) + py * 0.25
    ref.current.rotation.y = THREE.MathUtils.lerp(ref.current.rotation.y, -a + px * 0.3, 0.06)
    ref.current.rotation.x = THREE.MathUtils.lerp(ref.current.rotation.x, py * 0.12, 0.06)
  })

  return (
    <group ref={ref}>
      <RoundedBox args={[w, h, 0.05]} radius={0.06} smoothness={quality.fancy ? 4 : 1}>
        <meshPhysicalMaterial
          color={lead ? '#12160a' : '#101012'}
          transmission={quality.fancy ? 0.82 : 0}
          opacity={quality.fancy ? 1 : 0.55}
          transparent={!quality.fancy}
          thickness={0.4}
          roughness={0.22}
          ior={1.3}
          clearcoat={0.6}
          clearcoatRoughness={0.2}
        />
      </RoundedBox>
      <RoundedBox args={[w + 0.02, h + 0.02, 0.01]} radius={0.07} smoothness={1}>
        <meshBasicMaterial color="#c6ff3d" transparent opacity={lead ? 0.5 : 0.16} wireframe />
      </RoundedBox>
    </group>
  )
}

function Scene({ quality }) {
  const count = quality.fancy ? PANEL_COUNT_FULL : PANEL_COUNT_LITE
  const panels = useMemo(() => Array.from({ length: count }, (_, i) => i), [count])

  return (
    <>
      <ambientLight intensity={0.4} />
      <Environment resolution={quality.envResolution} frames={1}>
        <Lightformer form="rect" intensity={4.5} color="#c6ff3d" position={[3, 2, 4]} scale={[3, 3, 1]} />
        <Lightformer form="rect" intensity={2.5} color="#ffffff" position={[-4, -1, 3]} scale={[3, 3, 1]} />
        <Lightformer form="ring" intensity={2} color="#c6ff3d" position={[0, 4, -4]} scale={6} />
      </Environment>
      <Float speed={quality.reduceMotion ? 0 : 0.8} rotationIntensity={quality.reduceMotion ? 0 : 0.15} floatIntensity={quality.reduceMotion ? 0 : 0.3}>
        <group>
          {panels.map((i) => (
            <Panel key={i} index={i} total={panels.length} radius={2.5} quality={quality} lead={i === 0} />
          ))}
        </group>
      </Float>
      {quality.bloom && (
        <EffectComposer>
          <Bloom luminanceThreshold={0.3} luminanceSmoothing={0.9} intensity={0.55} mipmapBlur />
        </EffectComposer>
      )}
    </>
  )
}

export default function Hero3D() {
  const [ready, setReady] = useState(false)

  const quality = useMemo(() => {
    const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches
    const isSmallScreen = window.innerWidth < 760
    const isLowPower = (navigator.hardwareConcurrency || 8) <= 4
    const lite = isSmallScreen || isLowPower
    return {
      reduceMotion,
      dpr: lite ? [1, 1.4] : [1, 2],
      fancy: !lite,
      envResolution: lite ? 96 : 256,
      bloom: !lite,
    }
  }, [])

  return (
    <div className="hero3d">
      <Canvas
        dpr={quality.dpr}
        camera={{ position: [0, 0, 7.5], fov: 40 }}
        gl={{ antialias: true, alpha: true }}
        onCreated={() => setReady(true)}
      >
        <Suspense fallback={null}>
          <Scene quality={quality} />
        </Suspense>
      </Canvas>
      {!ready && <div className="hero3d-loading">Loading scene…</div>}
    </div>
  )
}
