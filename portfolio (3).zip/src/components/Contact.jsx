import Reveal from './Reveal.jsx'

const PLATFORM_LABELS = {
  email: 'Email',
  fiverr: 'Fiverr',
  linkedin: 'LinkedIn',
  github: 'GitHub',
  whatsapp: 'WhatsApp',
  instagram: 'Instagram',
}

function linkFor(key, value) {
  if (!value) return null
  if (key === 'email') return `mailto:${value}`
  if (key === 'whatsapp') return `https://wa.me/${value.replace(/[^\d]/g, '')}`
  return value
}

export default function Contact({ contact, name }) {
  const entries = Object.entries(contact || {}).filter(([, v]) => v)
  return (
    <section id="contact" className="contact-section">
      <div className="container">
        <Reveal>
          <p className="eyebrow">Contact</p>
          <h2 className="contact-title">Have a project in mind? Let's talk.</h2>
          <p className="contact-sub">Full product builds, freelance jobs, or a quick question about how something's made. All of it welcome.</p>
          {entries.length === 0 ? (
            <p className="contact-empty">Links coming soon.</p>
          ) : (
            <div className="contact-links">
              {entries.map(([key, value]) => (
                <a key={key} href={linkFor(key, value)} target="_blank" rel="noreferrer" className="btn glass">
                  {PLATFORM_LABELS[key] || key}
                </a>
              ))}
            </div>
          )}
          <p className="footer-note">© {new Date().getFullYear()} {name}. Built and shipped from a phone.</p>
        </Reveal>
      </div>
    </section>
  )
}
