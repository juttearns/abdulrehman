import Hero3D from './Hero3D.jsx'

export default function Hero({ profile }) {
  return (
    <section id="top" className="hero">
      <div className="hero-copy">
        <p className="eyebrow">{profile.location} · {profile.availableForWork ? 'Available for work' : 'Currently unavailable'}</p>
        <h1 className="hero-title">
          Full products, <span className="accent">built alone</span>, shipped from one phone.
        </h1>
        <p className="hero-sub">{profile.tagline}</p>
        <div className="hero-actions">
          <a href="#work" className="btn btn-primary">See the work</a>
          <a href="#contact" className="hero-secondary">Get in touch</a>
        </div>
      </div>
      <div className="hero3d-wrap">
        <Hero3D />
      </div>
    </section>
  )
}
