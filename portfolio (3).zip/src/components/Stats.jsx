import Reveal from './Reveal.jsx'

export default function Stats({ projectCount, skillCount }) {
  const items = [
    { num: '1', label: 'Phone, no laptop' },
    { num: String(projectCount), label: 'Products shipped' },
    { num: String(skillCount), label: 'Core tools' },
    { num: '100%', label: 'Solo, start to finish' },
  ]
  return (
    <Reveal as="section" className="stats">
      <div className="stats-row">
        {items.map((item) => (
          <div key={item.label} className="stat-cell">
            <div className="stat-num">{item.num}</div>
            <div className="stat-label">{item.label}</div>
          </div>
        ))}
      </div>
    </Reveal>
  )
}
