import { useState } from 'react'

// Change this before you deploy. This is a soft lock only (no backend) —
// anyone who reads the page source can find it, so don't rely on it for
// anything truly private.
const ADMIN_PASSWORD = 'zentro-admin'

const emptyProject = () => ({
  id: '',
  name: '',
  tagline: '',
  description: '',
  tags: [],
  link: '',
  blog: '',
})

function Field({ label, value, onChange, textarea, mono }) {
  return (
    <label className="admin-field">
      <span>{label}</span>
      {textarea ? (
        <textarea value={value || ''} onChange={(e) => onChange(e.target.value)} rows={4} />
      ) : (
        <input value={value || ''} onChange={(e) => onChange(e.target.value)} className={mono ? 'mono' : ''} />
      )}
    </label>
  )
}

function ProjectEditor({ project, onChange, onRemove }) {
  const set = (key, value) => onChange({ ...project, [key]: value })
  return (
    <div className="glass admin-project">
      <div className="admin-project-head">
        <Field label="Project ID (slug)" value={project.id} onChange={(v) => set('id', v)} mono />
        <button className="btn" onClick={onRemove} type="button">Remove</button>
      </div>
      <Field label="Name" value={project.name} onChange={(v) => set('name', v)} />
      <Field label="Tagline" value={project.tagline} onChange={(v) => set('tagline', v)} />
      <Field label="Description" value={project.description} onChange={(v) => set('description', v)} textarea />
      <Field label="Tags (comma separated)" value={(project.tags || []).join(', ')} onChange={(v) => set('tags', v.split(',').map((t) => t.trim()).filter(Boolean))} />
      <Field label="Link" value={project.link} onChange={(v) => set('link', v)} mono />
      <Field label="Notes / mini blog" value={project.blog} onChange={(v) => set('blog', v)} textarea />
    </div>
  )
}

export default function Admin({ content, saveDraft, clearDraft, usingDraft }) {
  const [unlocked, setUnlocked] = useState(false)
  const [pwd, setPwd] = useState('')
  const [draft, setDraft] = useState(content)
  const [savedFlash, setSavedFlash] = useState(false)

  if (!unlocked) {
    return (
      <div className="admin-lock">
        <div className="glass admin-lock-box">
          <h2>Admin</h2>
          <p>Enter password to edit site content.</p>
          <input
            type="password"
            value={pwd}
            onChange={(e) => setPwd(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && pwd === ADMIN_PASSWORD && setUnlocked(true)}
            placeholder="Password"
          />
          <button className="btn btn-primary" onClick={() => pwd === ADMIN_PASSWORD && setUnlocked(true)}>
            Unlock
          </button>
          <a href="#top" className="admin-back">← Back to site</a>
        </div>
      </div>
    )
  }

  const setProfile = (key, value) => setDraft({ ...draft, profile: { ...draft.profile, [key]: value } })
  const setContact = (key, value) => setDraft({ ...draft, contact: { ...draft.contact, [key]: value } })
  const setProject = (idx, next) => {
    const projects = [...draft.projects]
    projects[idx] = next
    setDraft({ ...draft, projects })
  }
  const removeProject = (idx) => {
    const projects = draft.projects.filter((_, i) => i !== idx)
    setDraft({ ...draft, projects })
  }
  const addProject = () => setDraft({ ...draft, projects: [...draft.projects, emptyProject()] })

  const handleSave = () => {
    saveDraft(draft)
    setSavedFlash(true)
    setTimeout(() => setSavedFlash(false), 1800)
  }

  const handleExport = () => {
    const blob = new Blob([JSON.stringify(draft, null, 2)], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = 'content.json'
    a.click()
    URL.revokeObjectURL(url)
  }

  return (
    <div className="admin-panel">
      <div className="container">
        <div className="admin-toolbar glass">
          <div>
            <h2>Admin panel</h2>
            <p className="admin-sub">
              {usingDraft ? 'Showing a saved local draft.' : 'Showing content.json.'} Edits below save to this
              browser only. Export and replace <code>public/content.json</code> in your repo, then redeploy,
              to make changes public.
            </p>
          </div>
          <div className="admin-actions">
            <a href="#top" className="btn">View site</a>
            <button className="btn" onClick={clearDraft} type="button">Clear local draft</button>
            <button className="btn btn-primary" onClick={handleSave} type="button">
              {savedFlash ? 'Saved ✓' : 'Save draft'}
            </button>
            <button className="btn btn-primary" onClick={handleExport} type="button">Export content.json</button>
          </div>
        </div>

        <section className="glass admin-section">
          <h3>Profile</h3>
          <Field label="Name" value={draft.profile.name} onChange={(v) => setProfile('name', v)} />
          <Field label="Role" value={draft.profile.role} onChange={(v) => setProfile('role', v)} />
          <Field label="Location" value={draft.profile.location} onChange={(v) => setProfile('location', v)} />
          <Field label="Hero tagline" value={draft.profile.tagline} onChange={(v) => setProfile('tagline', v)} textarea />
          <Field label="Bio" value={draft.profile.bio} onChange={(v) => setProfile('bio', v)} textarea />
          <Field label="Skills (comma separated)" value={(draft.profile.skills || []).join(', ')} onChange={(v) => setProfile('skills', v.split(',').map((t) => t.trim()).filter(Boolean))} />
        </section>

        <section className="glass admin-section">
          <h3>Contact links</h3>
          {Object.keys(draft.contact).map((key) => (
            <Field key={key} label={key} value={draft.contact[key]} onChange={(v) => setContact(key, v)} mono />
          ))}
        </section>

        <section className="admin-section">
          <div className="admin-section-head">
            <h3>Projects</h3>
            <button className="btn" onClick={addProject} type="button">+ Add project</button>
          </div>
          {draft.projects.map((p, i) => (
            <ProjectEditor key={i} project={p} onChange={(next) => setProject(i, next)} onRemove={() => removeProject(i)} />
          ))}
        </section>
      </div>
    </div>
  )
}
