import { useEffect, useState } from 'react'
import { useContent } from './hooks/useContent.js'
import Nav from './components/Nav.jsx'
import Hero from './components/Hero.jsx'
import Stats from './components/Stats.jsx'
import About from './components/About.jsx'
import Projects from './components/Projects.jsx'
import Contact from './components/Contact.jsx'
import Admin from './components/Admin.jsx'

export default function App() {
  const { content, loading, usingDraft, saveDraft, clearDraft } = useContent()
  const [hash, setHash] = useState(window.location.hash)

  useEffect(() => {
    const onHashChange = () => setHash(window.location.hash)
    window.addEventListener('hashchange', onHashChange)
    return () => window.removeEventListener('hashchange', onHashChange)
  }, [])

  if (loading || !content) {
    return <div className="loading-screen">Loading…</div>
  }

  if (hash === '#admin') {
    return <Admin content={content} saveDraft={saveDraft} clearDraft={clearDraft} usingDraft={usingDraft} />
  }

  return (
    <>
      <Nav name={content.profile.name} />
      <main>
        <Hero profile={content.profile} />
        <Stats projectCount={content.projects.length} skillCount={(content.profile.skills || []).length} />
        <About profile={content.profile} />
        <Projects projects={content.projects} />
        <Contact contact={content.contact} name={content.profile.name} />
      </main>
    </>
  )
}
