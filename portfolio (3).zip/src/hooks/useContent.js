import { useEffect, useState, useCallback } from 'react'

const DRAFT_KEY = 'portfolio_admin_draft_v1'

export function useContent() {
  const [content, setContent] = useState(null)
  const [loading, setLoading] = useState(true)
  const [usingDraft, setUsingDraft] = useState(false)

  useEffect(() => {
    fetch('/content.json')
      .then((res) => res.json())
      .then((base) => {
        const draftRaw = localStorage.getItem(DRAFT_KEY)
        if (draftRaw) {
          try {
            const draft = JSON.parse(draftRaw)
            setContent(draft)
            setUsingDraft(true)
          } catch {
            setContent(base)
          }
        } else {
          setContent(base)
        }
        setLoading(false)
      })
      .catch(() => setLoading(false))
  }, [])

  const saveDraft = useCallback((next) => {
    localStorage.setItem(DRAFT_KEY, JSON.stringify(next))
    setContent(next)
    setUsingDraft(true)
  }, [])

  const clearDraft = useCallback(() => {
    localStorage.removeItem(DRAFT_KEY)
    window.location.reload()
  }, [])

  return { content, loading, usingDraft, saveDraft, clearDraft }
}
